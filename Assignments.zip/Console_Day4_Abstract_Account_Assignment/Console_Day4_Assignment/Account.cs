﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day4_Assignment
{
    abstract class Account
    {
        private int AccountId;
        private string CustomerName;
        protected int AccountBalance;
        private static int count = 1000;
        public Account(string CustomerName, int AccountBalance)
        {
            this.AccountId = Account.count++;
            this.CustomerName = CustomerName;
            this.AccountBalance = AccountBalance;
            Console.WriteLine("Account Class Cunstructor");
        }
        public int GetBalance()
        {
            return this.AccountBalance;
        }
        public void StopPayment()
        {
            Console.WriteLine("Stop Payment Logic......");
        }
        public abstract void Deposit(int Amt);
        public abstract void Withdraw(int Amt);
        public int PAccountId
        {
            get
            {
                return this.AccountId;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
    }
}
