﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day4_Assignment
{
    class Current : Account
    {
        public Current(string CustomerName, int AccountBalance)
           : base(CustomerName, AccountBalance)
        {
            Console.WriteLine("Current Object Constructor");
        }

        public override void Deposit(int Amt)
        {
            this.AccountBalance = this.AccountBalance + Amt;
        }

        public override void Withdraw(int Amt)
        {
            this.AccountBalance = this.AccountBalance - Amt;
        }
    }
}
