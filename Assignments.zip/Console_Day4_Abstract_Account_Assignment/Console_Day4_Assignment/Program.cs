﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day4_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Customer Name :");
            string CustomerName = Console.ReadLine();
            Console.WriteLine("Enter Account Balance :");
            int AccountBalance = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Account Type :");
            string AccountType = Console.ReadLine();
            Account obj = null;
            if (AccountType == "Saving")
            {
                obj = new Saving(CustomerName, AccountBalance);
            }
            else if (AccountType == "Current")
            {
                obj = new Current(CustomerName, AccountBalance);
            }
            if (obj != null)
            {
                Console.WriteLine(obj.PAccountId);
                Console.WriteLine(obj.PCustomerName);
                int Balance = obj.GetBalance();
                Console.WriteLine("Balance :" + Balance);
                Console.WriteLine("Enter Amount to Deposit :");
                int Amount = Convert.ToInt32(Console.ReadLine());
                obj.Deposit(Amount);
                Balance = obj.GetBalance();
                Console.WriteLine("Balance :" + Balance);
                Console.WriteLine("Enter Amount to Withdraw :");
                Amount = Convert.ToInt32(Console.ReadLine());
                obj.Withdraw(Amount);
                Balance = obj.GetBalance();
                Console.WriteLine("Balance :" + Balance);
                obj.StopPayment();
            }
            Console.ReadLine();

        }
    }
}
