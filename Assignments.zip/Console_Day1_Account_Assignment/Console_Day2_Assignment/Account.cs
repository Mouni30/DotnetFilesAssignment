﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_Assignment
{
    class Account
    {
        private readonly int AccountId;
        private string CustomerName;
        private int Balance;
        public Account(int AccountId, string CustomerName, int Balance)
            : this(AccountId, CustomerName)
        {

            this.Balance = Balance;
            Console.WriteLine("Account Constructor 2");
        }
        public Account(int AccountId, string CustomerName)
            :this()
        {
            this.AccountId = AccountId;
            this.CustomerName = CustomerName;
            Console.WriteLine("Account Constructor 1");
        }
        public Account()
        {
            Console.WriteLine("Account Constructor 1");
        }
        public string GetDetails()
        {
            return this.AccountId + " " + this.CustomerName;
        }
        public void Deposit(int Amt)
        {
            this.Balance = this.Balance + Amt;

        }
        public void Withdraw(int Amt)
        {
            this.Balance = this.Balance - Amt;
        }
        public int GetBalance()
        {
            return this.Balance;
        }
    }
}
