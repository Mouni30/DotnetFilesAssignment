﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Account ID :");
            int AccountId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Customer Name :");
            string CustomerName = Console.ReadLine();
            Console.WriteLine("Enter Balance :");
            int Balance = Convert.ToInt32(Console.ReadLine());
            Account obj = new Account(AccountId, CustomerName, Balance);
            string details = obj.GetDetails();
            Console.WriteLine(details);
            Console.WriteLine("Enter Deposit Amount :");
            int Amt = Convert.ToInt32(Console.ReadLine());
            obj.Deposit(Amt);
            int Bal = obj.GetBalance();
            Console.WriteLine("Balance :" + Bal);
            Console.WriteLine("Enter Withdraw Amount :");
            Amt = Convert.ToInt32(Console.ReadLine());
            obj.Withdraw(Amt);
            Bal = obj.GetBalance();
            Console.WriteLine("Balance :" + Bal);
            Bal = obj.GetBalance();
            Console.WriteLine("Balance :" + Bal);



            /*
            Console.WriteLine("Enter Employee ID : ");
            int EmpId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Name : ");
            string EmpName = Console.ReadLine();
            Console.WriteLine("Enter Employee Salary : ");
            double EmpSalary = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter City : ");
            string EmpCity = Console.ReadLine();
            Employee obj = new Employee(EmpId, EmpName, EmpSalary, EmpCity);
            string str = obj.GetDetails();
            Console.WriteLine(str);
            Console.WriteLine("Enter Days : ");
            int Days = Convert.ToInt32(Console.ReadLine());
            double Salary = obj.GetSalary(Days);
            Console.WriteLine(Salary);

            Console.WriteLine("Enter Customer ID :");
            int CustomerId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Customer Name :");
            string CustomerName = Console.ReadLine();
            Console.WriteLine("Enter Customer Email ID :");
            string CustomerEmailId = Console.ReadLine();
            Customer obj = new Customer(CustomerId, CustomerName,CustomerEmailId);
            string str = obj.GetDetails();
            Console.WriteLine(str);
            */
            Console.ReadLine();
        }
    }
}
