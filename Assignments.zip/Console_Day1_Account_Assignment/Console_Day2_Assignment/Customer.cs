﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_Assignment
{
    class Customer
    {
        private int CustomerId;
        private string CustomerName;
        private string CustomerEmailId;
       
        public Customer(int CustomerId, string CustomerName, string CustomerEmailId)
            :this(CustomerId,CustomerName)
        {
            
            this.CustomerEmailId = CustomerEmailId;
            Console.WriteLine("Parameter Constructor");
        }
        public Customer(int CustomerId, string CustomerName)
            :this()
        {
            this.CustomerId = CustomerId;
            this.CustomerName = CustomerName;
            Console.WriteLine("Parameter Constructor");
        }
        public Customer()
        {
            Console.WriteLine("Parameter Constructor");
        }
        public string GetDetails()
        {
            return this.CustomerId + " " + this.CustomerName + " " + this.CustomerEmailId;
        }
    }
}
