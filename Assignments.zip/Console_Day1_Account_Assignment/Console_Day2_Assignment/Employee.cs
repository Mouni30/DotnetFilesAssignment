﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_Assignment
{
    class Employee
    {
        private int EmpId;
        private string EmpName;
        private double EmpSalary;
        private string EmpCity;
        public Employee(int EmpId, string EmpName, double EmpSalary, string EmpCity)
            :this(EmpId,EmpName)
        {
            
            this.EmpSalary = EmpSalary;
            this.EmpCity = EmpCity;
            Console.WriteLine("Employee Constructor3");
        }
        public Employee(int EmpId, string EmpName)
            :this()
        {
            this.EmpId = EmpId;
            this.EmpName = EmpName;
            Console.WriteLine("Employee Constructor 2");
        }
        public Employee()
        {
            Console.WriteLine("Employee Constructor 1");
        }
        public string GetDetails()
        {
            return this.EmpId + " " + this.EmpName + " " + this.EmpCity;
        }
        public double GetSalary(int Days)
        {
            return (this.EmpSalary / 30) * Days;
        }
    }
}
