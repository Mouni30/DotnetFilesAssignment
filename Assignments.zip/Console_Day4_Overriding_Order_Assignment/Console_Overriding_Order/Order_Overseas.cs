﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding_Order
{
    class Order_Overseas : Order
    {
        public Order_Overseas(string CustomerName,int ItemQuantity,int ItemPrice)
            :base(CustomerName,ItemQuantity,ItemPrice)
        {
            Console.WriteLine("Order Overseas Object Constructor");
        }
        public override int GetOrderValue()
        {
            return (this.ItemQuantity * this.ItemPrice) - 10;
        }
    }
}
