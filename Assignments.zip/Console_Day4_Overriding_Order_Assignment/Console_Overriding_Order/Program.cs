﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding_Order
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Customer Name :");
            string CustomerName = Console.ReadLine();
            Console.WriteLine("Enter Item Quantity :");
            int ItemQuantity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Item Price :");
            int ItemPrice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Order Type :");
            string OrderType = Console.ReadLine();
            Order obj = null;
            if (OrderType == "Normal")
            {
                obj = new Order(CustomerName,ItemQuantity,ItemPrice);
            }
            else if (OrderType == "Overseas")
            {
                obj = new Order_Overseas(CustomerName,ItemQuantity,ItemPrice);
            }
            if (obj != null)
            {
                Console.WriteLine(obj.POrderId);
                Console.WriteLine(obj.PCustomerName);
                int Value = obj.GetOrderValue();
                Console.WriteLine(Value);
            }
            Console.ReadLine();
        }
    }
}
