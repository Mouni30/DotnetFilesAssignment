﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding_Order
{
    class Order
    {
        private int OrderId;
        private string CustomerName;
        protected int ItemQuantity;
        protected int ItemPrice;
        private static int count = 1000;
        public Order(string CustomerName,int ItemQuantity,int ItemPrice)
        {
            this.OrderId = Order.count++;
            this.CustomerName = CustomerName;
            this.ItemQuantity = ItemQuantity;
            this.ItemPrice = ItemPrice;
            Console.WriteLine("Order Object Constructor");
        }
        public virtual int GetOrderValue()
        {
            return this.ItemQuantity * this.ItemPrice;
        }
        public int POrderId
        {
            get
            {
                return this.OrderId;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
    }
}
