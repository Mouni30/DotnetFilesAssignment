﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Calculator_Library_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter n1 :");
            int n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter n2 :");
            int n2 = Convert.ToInt32(Console.ReadLine());
            Calculator_Library.Calculator_Class obj = new Calculator_Library.Calculator_Class();
            int total = obj.GetSum(n1, n2);
            Console.WriteLine("Sum :" + total);
            total = obj.GetMultuiply(n1, n2);
            Console.WriteLine("Multiply :" + total);
            total = obj.GetDivide(n1, n2);
            Console.WriteLine("Divide :" + total);
            total = obj.GetSubtract(n1, n2);
            Console.WriteLine("Subtract :" + total);
            Console.ReadLine();
        }
    }
}
