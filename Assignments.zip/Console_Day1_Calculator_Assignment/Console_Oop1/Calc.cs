﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Oop1
{
    class Calc
    {
        public int Number1;
        public int Number2;
        public int Sum()
        {
            return Number1 + Number2;
        }
        public int Subtract()
        {
            return Number1 - Number2;
        }

    }
}
