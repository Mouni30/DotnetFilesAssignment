﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Assignment
{
    class Emp
    {
        private int EmpId;
        private string EmpName;
        private string EmpCity;
        public Emp(int EmpId,string EmpName,string EmpCity)
        {
            this.EmpId = EmpId;
            this.EmpName = EmpName;
            this.EmpCity = EmpCity;
            Console.WriteLine("Employee Object Constructor");
        }
        public int PEmpId
        {
            get
            {
                return this.EmpId;
            }
        }
        public string PEmpName
        {
            get
            {
                return this.EmpName;
            }
        }
        public string PEmpCity
        {
            get
            {
                return this.EmpCity;
            }
        }
    }
}
