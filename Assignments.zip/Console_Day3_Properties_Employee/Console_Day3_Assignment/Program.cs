﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Employee ID :");
            int EmpId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Name :");
            string EmpName = Console.ReadLine();
            Console.WriteLine("Enter Employee City :");
            string EmpCity = Console.ReadLine();
            Emp obj = new Emp(EmpId, EmpName, EmpCity);
            Console.WriteLine(obj.PEmpId);
            Console.WriteLine(obj.PEmpName);
            Console.WriteLine(obj.PEmpCity);
            Console.ReadLine();
        }
    }
}
