﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Order
{
    class Oop2
    {
        public int OrderId;
        public string CustomerName;
        public string ItemName;
        public int ItemQuantity;
        public int ItemPrice;
        public int getOrderValue()
        {
            return ItemQuantity * ItemPrice;
        }







        //public Oop2(int OrderId,string CustomerName,string ItemName,int ItemQuantity,int ItemPrice)
        //    :this(OrderId, CustomerName)
        //{
        //    this.ItemName = ItemName;
        //    this.ItemQuantity = ItemQuantity;
        //    this.ItemPrice = ItemPrice;
        //    Console.WriteLine("Order Constructor 3");
        //}
        //public Oop2(int OrderId, string CustomerName)
        //    :this()
        //{
        //    this.OrderId = OrderId;
        //    this.CustomerName = CustomerName;
        //    Console.WriteLine("Order Constructor 2");
        //}
        //public Oop2()
        //{
        //    Console.WriteLine("Order Constructor 1");
        //}
        //public string GetDetails()
        //{
        //    return this.OrderId + " " + this.CustomerName + " " + this.ItemName;
        //}
        public int GetOrderAmount()
        {
            return this.ItemQuantity * this.ItemPrice;
        }

        public int getOrderValue()
        {
            return ItemQuantity * ItemPrice;
        }
    }
}
