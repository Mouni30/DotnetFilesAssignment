﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Order
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Order ID :");
            int OrderId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Customer Name :");
            string CustomerName = Console.ReadLine();
            Console.WriteLine("Enter Item Name :");
            string ItemName = Console.ReadLine();
            Console.WriteLine("Enter Item Quantity :");
            int ItemQuantity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Item Price :");
            int ItemPrice = Convert.ToInt32(Console.ReadLine());
            Oop2 obj = new Oop2();
            obj.ItemQuantity = ItemQuantity;
            obj.ItemPrice = ItemPrice;
            int result = obj.getOrderValue();
            Console.WriteLine("Order Value :" + result);

            Console.ReadLine();






            //Oop2 obj = new Oop2(OrderId,CustomerName,ItemName,ItemQuantity,ItemPrice);
            ////int result = obj.getOrderValue();
            //string result = obj.GetDetails();
            //Console.WriteLine(result);
            //int value = obj.GetOrderAmount();
            //Console.WriteLine("Order Value :" + value);
            Console.ReadLine();
        }
    }
}
