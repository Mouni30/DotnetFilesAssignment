﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Employee_Assignment
{
    interface IManagerEmp
    {
        int GetEmployeeId();
        int GetEmployeeExp();
        string GetEmployeeProjectDetails();
    }
}
