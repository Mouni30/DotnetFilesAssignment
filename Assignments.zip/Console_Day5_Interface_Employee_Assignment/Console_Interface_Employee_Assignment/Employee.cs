﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Employee_Assignment
{
    class Employee : IHREmp, IAccountEmp, IManagerEmp
    {
        private int EmployeeId;
        private string EmployeeName;
        private string EmployeeCity;
        private int EmployeeSalary;
        private string EmployeeAddress;
        private string EmployeeProjectDetails;
        private int EmployeeExp;
        private int EmployeeAccountNumber;
        private string EmployeeAccBankName;
        private int EmployeeAge;
        public static int count = 1000;
        public Employee(string EmployeeName, string EmployeeCity, int EmployeeSalary,
            string EmployeeAddress, string EmployeeProjectDetails, int EmployeeExp,
            int EmployeeAccountNumber, string EmployeeAccBankName, int EmployeeAge)
        {
            this.EmployeeId = ++Employee.count;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
            this.EmployeeSalary = EmployeeSalary;
            this.EmployeeAddress = EmployeeAddress;
            this.EmployeeProjectDetails = EmployeeProjectDetails;
            this.EmployeeExp = EmployeeExp;
            this.EmployeeAccountNumber = EmployeeAccountNumber;
            this.EmployeeAccBankName = EmployeeAccBankName;
            this.EmployeeAge = EmployeeAge;
        }
        public string GetEmployeeAddress()
        {
            return this.EmployeeAddress;
        }

        public int GetEmployeeSalary()
        {
            return this.EmployeeSalary;
        }

        public int GetEmployeeId()
        {
            return this.EmployeeId;
        }

        public int GetEmployeeAccountNumber()
        {
            return this.EmployeeAccountNumber;
        }

        public int GetEmployeeExp()
        {
            return this.EmployeeExp;
        }

        public string GetEmployeeProjectDetails()
        {
            return this.EmployeeProjectDetails;
        }

        public int PEmployeeId
        {
            get
            {
                return this.EmployeeId;
            }
        }
        public string PEmployeeName
        {
            get
            {
                return this.EmployeeName;
            }
        }
        public string PEmployeeCity
        {
            get
            {
                return this.EmployeeCity;
            }
        }
        public int PEmployeeSalary
        {
            get
            {
                return this.EmployeeSalary;
            }
        }
        public string PEmployeeAddress
        {
            get
            {
                return this.PEmployeeAddress;
            }
        }
        public string PEmployeeProjectDetails
        {
            get
            {
                return this.EmployeeProjectDetails;
            }
        }
        public int PEmployeeExp
        {
            get
            {
                return this.EmployeeExp;
            }
        }
        public int PEmployeeAccountNumber
        {
            get
            {
                return this.EmployeeAccountNumber;
            }
        }
        public string PEmployeeAccBankName
        {
            get
            {
                return this.EmployeeAccBankName;
            }
        }
        public int PEmployeeAge
        {
            get
            {
                return this.EmployeeAge;
            }
        }

    }
}
