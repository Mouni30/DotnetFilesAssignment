﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Employee_Assignment
{
    class Manager
    {
        public void GetEmployee(IManagerEmp Manobj)
        {
            int ID = Manobj.GetEmployeeId();
            Console.WriteLine("Manager ID :" + ID);
            int Exp = Manobj.GetEmployeeExp();
            Console.WriteLine("Manager Exp :" + Exp);
            string ProjectDetails = Manobj.GetEmployeeProjectDetails();
            Console.WriteLine("Manager Project Details :" + ProjectDetails);
        }

    }
}
