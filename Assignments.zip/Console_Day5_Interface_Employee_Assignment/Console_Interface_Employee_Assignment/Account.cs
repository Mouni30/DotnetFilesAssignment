﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Employee_Assignment
{
    class Account
    {
        public void GetEmployee(IAccountEmp Accobj)
        {
            int ID = Accobj.GetEmployeeId();
            Console.WriteLine("Account ID :" + ID);
            int Salary = Accobj.GetEmployeeSalary();
            Console.WriteLine("Account Salary :" + Salary);
            int AccNo = Accobj.GetEmployeeAccountNumber();
            Console.WriteLine("Account Account Number :" + AccNo);

        }
    }
}
