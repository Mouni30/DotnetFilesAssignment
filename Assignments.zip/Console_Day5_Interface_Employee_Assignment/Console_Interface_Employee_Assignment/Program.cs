﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Employee_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee obj = new Employee("Mouni", "BGL", 30000, "XYZ", "Dotnet", 2, 1234, "SBI", 21);
            Console.WriteLine();
            Console.WriteLine("********** HR **********");
            HR obj1 = new HR();
            obj1.GetEmployee(obj);
            Console.WriteLine();
            Console.WriteLine("********** Account **********");
            Account obj2 = new Account();
            obj2.GetEmployee(obj);
            Console.WriteLine();
            Console.WriteLine("********** Manager **********");
            Manager obj3 = new Manager();
            obj3.GetEmployee(obj);
            Console.ReadLine();
        }
    }
}
