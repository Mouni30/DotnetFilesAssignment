﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Employee_Assignment
{
    class HR
    {
        public void GetEmployee(IHREmp Hrobj)
        {
            int ID = Hrobj.GetEmployeeId();
            Console.WriteLine("HR ID :" + ID);
            int Salary = Hrobj.GetEmployeeSalary();
            Console.WriteLine("HR Salary :" + Salary);
            string Address = Hrobj.GetEmployeeAddress();
            Console.WriteLine("HR Address :" + Address);

        }
    }
}
