﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Customer Name :");
            string CustomerName = Console.ReadLine();
            Console.WriteLine("Enter Customer Email ID :");
            string CustomerEmailId = Console.ReadLine();
            Console.WriteLine("Enter Customer Type :");
            string CustomerType = Console.ReadLine();
            if (CustomerType != "Online")
            {
                Customer obj = new Customer(CustomerName, CustomerEmailId);
                Console.WriteLine(obj.PCustomerId);
                Console.WriteLine(obj.PCustomerName);
                Console.WriteLine(obj.PCustomerEmailId);
            }
            else
            {
                Console.WriteLine("Enter Payment :");
                string Payment = Console.ReadLine();
                Console.WriteLine("Enter Home Address :");
                string HomeAddress = Console.ReadLine();
                Customer_Online obj = new Customer_Online(CustomerName, CustomerEmailId, Payment, HomeAddress);
                Console.WriteLine(obj.PCustomerId);
                Console.WriteLine(obj.PCustomerName);
                Console.WriteLine(obj.PCustomerEmailId);
                Console.WriteLine(obj.PPayment);
                Console.WriteLine(obj.PHomeAddress);
            }
            Console.ReadLine();
        }
    }
}
