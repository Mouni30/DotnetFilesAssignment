﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Assignment1
{
    class Customer
    {
        private int CustomerId;
        private string CustomerName;
        private string CustomerEmailId;
        private static int count = 1000;
        public Customer(string CustomerName, string CustomerEmailId)
        {
            Customer.count++;
            this.CustomerId = Customer.count;
            this.CustomerName = CustomerName;
            this.CustomerEmailId = CustomerEmailId;
            Console.WriteLine("Customer Object Constructor");
        }
        public int PCustomerId
        {
            get
            {
                return this.CustomerId;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public string PCustomerEmailId
        {
            get
            {
                return this.CustomerEmailId;
            }
        }
    }
}
