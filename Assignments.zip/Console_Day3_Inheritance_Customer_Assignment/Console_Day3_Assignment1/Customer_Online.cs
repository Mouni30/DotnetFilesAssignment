﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Assignment1
{
    class Customer_Online : Customer
    {
        private string Payment;
        private string HomeAddress;
        public Customer_Online(string CustomerName, string CustomerEmailId, string Payment, string HomeAddress) : base(CustomerName, CustomerEmailId)
        {
            this.Payment = Payment;
            this.HomeAddress = HomeAddress;
            Console.WriteLine("Customer Online Object Constructor");
        }
        public string PPayment
        {
            get
            {
                return this.Payment;
            }
        }
        public string PHomeAddress
        {
            get
            {
                return this.HomeAddress;
            }
        }
    }
}
