﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Loan
{
    abstract class Loan
    {
        private int LoanId;
        private string CustomerName;
        private string CustomerEmailId;
        private int CustomerMobileNo;
        protected int LoanAmount;
        protected int Duration;
        protected int Rate;
        private static int count = 1000;
        public Loan(string CustomerName,string CustomerEmailId,int CustomerMobileNo,int LoanAmount,int Duration,int Rate)
        {
            this.LoanId = Loan.count++;
            this.CustomerName = CustomerName;
            this.CustomerEmailId = CustomerEmailId;
            this.CustomerMobileNo = CustomerMobileNo;
            this.LoanAmount = LoanAmount;
            this.Duration = Duration;
            this.Rate = Rate;
            Console.WriteLine("Loan abstract Class Constructor");
        }
        public abstract void PayEMI(int Amount);
        public int GetPendingLoan()
        {
            return this.LoanAmount;
        }
        public int PLoanId
        {
            get
            {
                return this.LoanId;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public string PCustomerEmailId
        {
            get
            {
                return this.CustomerEmailId;
            }
        }
        public int PCustomerMobileNo
        {
            get
            {
                return this.CustomerMobileNo;
            }
        }
        public int PLoanAmount
        {
            get
            {
                return this.LoanAmount;
            }
        }
        public int PDuration
        {
            get
            {
                return this.Duration;
            }
        }
        public int PRate
        {
            get
            {
                return this.Rate;
            }
        }

    }
}
