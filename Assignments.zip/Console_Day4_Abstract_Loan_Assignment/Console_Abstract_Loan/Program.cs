﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Loan
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter Customer Name :");
            string CustomerName = Console.ReadLine();
            Console.WriteLine("Enter Customer Email ID :");
            string CustomerEmailId = Console.ReadLine();
            Console.WriteLine("Enter Customer Mobile Number :");
            int CustomerMobileNo =Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Loan Amount :");
            int LoanAmount = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Duration :");
            int Duration = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Rate :");
            int Rate = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Loan Type :");
            string LoanType = Console.ReadLine();
            Loan obj = null;
            if (LoanType == "HomeLoan")
            {
                obj = new HomeLoan(CustomerName, CustomerEmailId, CustomerMobileNo, LoanAmount, Duration, Rate);
            }
            else if (LoanType == "VehicleLoan")
            {
                obj = new VehicleLoan(CustomerName, CustomerEmailId, CustomerMobileNo, LoanAmount, Duration, Rate);
            }
            if (obj != null)
            {
                Console.WriteLine(obj.PLoanId);
                Console.WriteLine(obj.PCustomerName);
                Console.WriteLine(obj.PCustomerEmailId);
                Console.WriteLine(obj.PCustomerMobileNo);
                Console.WriteLine(obj.PLoanAmount);
                Console.WriteLine(obj.PDuration);
                Console.WriteLine(obj.PRate);
                int n = obj.GetPendingLoan();
                Console.WriteLine("Loan Amount :" + n);
                Console.WriteLine("Enter Amount to Pay EMI :");
                int Amount = Convert.ToInt32(Console.ReadLine());
                obj.PayEMI(Amount);
                Console.WriteLine(Amount);
                n = obj.GetPendingLoan();
                Console.WriteLine("Loan Amount :" + n);
            }
            Console.ReadLine();
        }
    }
}
