﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Loan
{
    class VehicleLoan : Loan
    {
        public VehicleLoan(string CustomerName, string CustomerEmailId, int CustomerMobileNo, int LoanAmount, int Duration, int Rate)
            :base(CustomerName,CustomerEmailId,CustomerMobileNo,LoanAmount,Duration,Rate)
        {
            Console.WriteLine("VehileLoan Object Constructor");
        }

        public override void PayEMI(int Amount)
        {
            this.LoanAmount = this.LoanAmount - ((this.LoanAmount * (this.Rate / 100)) + Amount)-2000;
        }
    }
}
