﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day4_Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Employee Name :");
            string EmployeeName = Console.ReadLine();
            Console.WriteLine("Enter Employee Monthly Salary :");
            double MonthlySalary = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Employee Type :");
            string EmployeeType = Console.ReadLine();
            Employee obj = null;
            if (EmployeeType == "Normal")
            {
                obj = new Employee(EmployeeName, MonthlySalary);
            }
            else if (EmployeeType == "Contract")
            {
                obj = new Employee_Contract(EmployeeName, MonthlySalary);
            }
            else
            {
                obj = new Employee_Trainee(EmployeeName, MonthlySalary);
            }
            if (obj != null)
            {
                Console.WriteLine(obj.PEmployeeId);
                Console.WriteLine(obj.PEmployeeName);
                Console.WriteLine(obj.PMonthlySalary);
                string Details = obj.GetDetails();
                Console.WriteLine(Details);
                string Work = obj.GetWork();
                Console.WriteLine(Work);
                Console.WriteLine("Enter No of Days :");
                int Days = Convert.ToInt32(Console.ReadLine());
                double Salary = obj.GetSalary(Days);
                Console.WriteLine("Salary" + Salary);
            }
            Console.ReadLine();

        }
    }
}
