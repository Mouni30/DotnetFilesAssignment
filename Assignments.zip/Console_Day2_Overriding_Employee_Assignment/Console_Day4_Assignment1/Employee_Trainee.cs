﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day4_Assignment1
{
    class Employee_Trainee : Employee
    {
        public Employee_Trainee(string EmployeeName, double MonthlySalary)
            : base(EmployeeName, MonthlySalary)
        { }
        public override double GetSalary(int Days)
        {
            double total = (this.PMonthlySalary / 30) * Days - 2000;
            return total;
        }
    }
}
