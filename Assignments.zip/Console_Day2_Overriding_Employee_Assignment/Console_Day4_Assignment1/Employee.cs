﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day4_Assignment1
{
    class Employee
    {
        private int EmployeeId;
        private string EmployeeName;
        private double MonthlySalary;
        private static int count = 1000;
        public Employee(string EmployeeName, double MonthlySalary)
        {
            this.EmployeeId = ++Employee.count;
            this.EmployeeName = EmployeeName;
            this.MonthlySalary = MonthlySalary;
        }
        public int PEmployeeId
        {
            get
            {
                return this.EmployeeId;
            }
        }
        public string PEmployeeName
        {
            get
            {
                return this.EmployeeName;
            }
        }
        public double PMonthlySalary
        {
            get
            {
                return this.MonthlySalary;
            }
        }
        public string GetDetails()
        {
            return this.EmployeeId + " " + this.EmployeeName;
        }
        public string GetWork()
        {
            return "Dotnet Developer";
        }
        public virtual double GetSalary(int Days)
        {
            int Bonus = 2000;
            int TDS = 800;
            double total = (this.MonthlySalary / 30) * Days + Bonus - TDS;
            return total;
        }
    }
}
